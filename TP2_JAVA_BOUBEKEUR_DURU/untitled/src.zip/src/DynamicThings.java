/* DynamicThings : représente un élément qui peut bouger
   et qui possède une animation (ex : héros, monstre).
*/
public class DynamicThings extends AnimatedThings {

    protected int speedX; // vitesse horizontale
    protected int speedY; // vitesse verticale

    public DynamicThings(int x, int y, int width, int height, int speedX, int speedY) {
        super(x, y, width, height); // appelle le constructeur de AnimatedThings
        this.speedX = speedX;
        this.speedY = speedY;
    }
}
