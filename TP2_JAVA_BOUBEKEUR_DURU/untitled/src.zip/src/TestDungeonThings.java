public class TestDungeonThings {

    public static void main(String[] args) {

        TileManager tm = new TileManager(32, 32);
        Dungeon d = new Dungeon(10, 8, tm);

        d.fillThingsArray(); // remplit la liste

        System.out.println("Nombre d'objets Things dans le donjon : " +
                           d.getThingsList().size());
    }
}
