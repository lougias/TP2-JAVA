/* Classe Things : représente un élément affichable du décor
   Elle a une position et une taille (en pixels).
*/
public class Things {

    protected int x;      // position horizontale
    protected int y;      // position verticale
    protected int width;  // largeur de l'élément
    protected int height; // hauteur de l'élément

    /* Constructeur : initialise la position et la taille du Things */
    public Things(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }
}
