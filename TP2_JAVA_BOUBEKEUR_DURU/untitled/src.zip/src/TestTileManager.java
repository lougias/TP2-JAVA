public class TestTileManager {

    public static void main(String[] args) {

        TileManager tm = new TileManager(32, 32);

        System.out.println("Largeur tuile = " + tm.getWidth());
        System.out.println("Hauteur tuile = " + tm.getHeight());
    }
}
