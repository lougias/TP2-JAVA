/* Classe TileManager
   Sert à gérer les tuiles du jeu (images carrées ou rectangulaires utilisées pour dessiner le décor)
   Stocke uniquement la largeur et la hauteur d'une tuile
*/
public class TileManager {

    // largeur d'une tuile en pixels (ne pourra jamais changer → final)
    private final int width;

    // hauteur d'une tuile en pixels (ne pourra jamais changer → final)
    private final int height;

    /* constructeur : permet d'initialiser la taille des tuiles
       exemple : new TileManager(32, 32) pour des tuiles 32x32 pixels
    */
    public TileManager(int width, int height) {
        this.width = width;   // on stocke la largeur donnée en paramètre
        this.height = height; // on stocke la hauteur donnée en paramètre
    }

    /* getter pour récupérer la largeur des tuiles */
    public int getWidth() {
        return width; // retourne la largeur en pixels
    }

    /* getter pour récupérer la hauteur des tuiles */
    public int getHeight() {
        return height; // retourne la hauteur en pixels
    }

}
