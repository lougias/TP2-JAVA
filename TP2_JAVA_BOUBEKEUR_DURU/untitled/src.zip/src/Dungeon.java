import java.util.ArrayList;

/* Classe Dungeon
   Représente le donjon sous forme de grille de caractères et,
   dans cette version, une liste d'objets Things correspondant
   aux éléments du décor (sol ou mur).
*/
public class Dungeon {

    private final int width;    // largeur du donjon (en cases)
    private final int height;   // hauteur du donjon (en cases)
    private char[][] map;       // carte du donjon sous forme de tableau 2D
    private TileManager tileManager;

    // Liste dynamique contenant tous les éléments du donjon (sol et murs)
    private ArrayList<Things> thingsList;

    /* Constructeur du donjon */
    public Dungeon(int width, int height, TileManager tileManager) {

        this.width = width;
        this.height = height;
        this.tileManager = tileManager;

        map = new char[height][width];
        thingsList = new ArrayList<>(); // tableau dynamique

        // Remplissage du tableau map
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {

                if (x == 0 || y == 0 || x == width - 1 || y == height - 1) {
                    map[y][x] = 'W';  // mur
                } else {
                    map[y][x] = ' ';  // sol
                }
            }
        }
    }

    /* Méthode qui remplit la liste thingsList
       en créant un objet Things ou SolidThings
       selon le caractère présent dans map.
    */
    public void fillThingsArray() {

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {

                // Position de l'objet en pixels
                int pixelX = x * tileManager.getWidth();
                int pixelY = y * tileManager.getHeight();

                if (map[y][x] == ' ') {

                    // Case vide = sol → Things
                    Things t = new Things(pixelX, pixelY,
                                          tileManager.getWidth(),
                                          tileManager.getHeight());
                    thingsList.add(t);

                } else if (map[y][x] == 'W') {

                    // Mur → SolidThings avec HitBox
                    SolidThings wall = new SolidThings(pixelX, pixelY,
                                                       tileManager.getWidth(),
                                                       tileManager.getHeight());
                    thingsList.add(wall);
                }
            }
        }
    }

    /* Affiche le donjon dans la console avec la position du héros */
    public void displayDungeonInConsole(HitBox hero) {

        int heroX = hero.getX() / tileManager.getWidth();
        int heroY = hero.getY() / tileManager.getHeight();

        for (int y = 0; y < height; y++) {

            for (int x = 0; x < width; x++) {

                if (x == heroX && y == heroY) {
                    System.out.print("H");
                } else {
                    System.out.print(map[y][x]);
                }
            }
            System.out.println();
        }
    }

    /* Getter pour récupérer la liste des Things */
    public ArrayList<Things> getThingsList() {
        return thingsList;
    }
}
