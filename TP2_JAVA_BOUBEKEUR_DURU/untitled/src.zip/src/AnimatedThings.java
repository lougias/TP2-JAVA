/* AnimatedThings : représente un élément animé
   (ex : torche, feu, créature immobile animée).
*/
public class AnimatedThings extends Things {

    public AnimatedThings(int x, int y, int width, int height) {
        super(x, y, width, height); // même constructeur que Things
    }
}
