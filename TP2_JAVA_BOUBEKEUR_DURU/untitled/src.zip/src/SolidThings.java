/* SolidThings : représente un objet solide du décor
   (ex : mur, coffre, barrière). Il possède une HitBox
   de la même taille que l'objet pour gérer les collisions.
*/
public class SolidThings extends Things {

    private HitBox hitBox;  // zone de collision

    public SolidThings(int x, int y, int width, int height) {
        super(x, y, width, height);       // appelle le constructeur de Things
        this.hitBox = new HitBox(x, y, width, height); // hitbox identique
    }

    public HitBox getHitBox() {
        return hitBox;
    }
}
