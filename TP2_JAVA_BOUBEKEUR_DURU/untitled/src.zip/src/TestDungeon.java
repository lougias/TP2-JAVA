public class TestDungeon {

    public static void main(String[] args) {

        TileManager tm = new TileManager(32, 32); // chaque case fait 32x32 pixels
        Dungeon d = new Dungeon(10, 8, tm);       // donjon 10 cases de large, 8 de haut

        HitBox hero = new HitBox(64, 64, 32, 32); // héros placé en case (2,2)

        d.displayDungeonInConsole(hero);
    }
}
